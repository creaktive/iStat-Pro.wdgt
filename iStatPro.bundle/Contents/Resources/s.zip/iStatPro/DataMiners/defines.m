//
//  defines.m
//  iStatPro
//
//  Created by Buffy Summers on 21/07/08Monday.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "defines.h"


@implementation defines

@end
